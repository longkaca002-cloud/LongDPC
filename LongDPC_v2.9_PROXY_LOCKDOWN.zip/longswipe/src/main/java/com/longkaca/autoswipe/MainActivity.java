package com.longkaca.autoswipe;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String[] TIKTOK_LITE_PACKAGES = {
            SwipeAccessibilityService.TIKTOK_LITE,
            "com.zhiliaoapp.musically.go"
    };
    private TextView status;
    private TextView commentSuggestion;
    private String currentComment;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(20));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("LONG AUTO SWIPE 1.3\nTikTok Lite · 10–15 giây");
        title.setTextSize(23);
        title.setTextColor(Color.BLACK);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("App chỉ vuốt lên khi TikTok Lite đang ở trước màn hình. Like và bình luận cần chính bạn xác nhận để tránh gửi nhầm hoặc spam.\n\nLần đầu: mở Trợ năng và bật Long Auto Swipe.");
        note.setTextSize(16);
        note.setPadding(0, dp(18), 0, dp(12));
        root.addView(note);

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0, dp(8), 0, dp(16));
        root.addView(status);

        root.addView(button("1. MỞ TRỢ NĂNG", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("2. BẮT ĐẦU VÀ MỞ TIKTOK LITE", v -> startWatching()));
        root.addView(button("DỪNG TỰ VUỐT", v -> setRunning(false)));

        TextView commentTitle = new TextView(this);
        commentTitle.setText("\nGợi ý bình luận tiếng Nhật (hãy sửa phần trong [ ]):");
        commentTitle.setTextSize(16);
        commentTitle.setTextColor(Color.BLACK);
        root.addView(commentTitle);

        commentSuggestion = new TextView(this);
        commentSuggestion.setTextSize(18);
        commentSuggestion.setTextColor(Color.rgb(25, 60, 130));
        commentSuggestion.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(commentSuggestion);
        showNewComment();

        root.addView(button("GỢI Ý KHÁC", v -> showNewComment()));
        root.addView(button("SAO CHÉP GỢI Ý", v -> copyComment()));
        setContentView(scroll);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void startWatching() {
        setRunning(true);
        Intent launch = null;
        for (String packageName : TIKTOK_LITE_PACKAGES) {
            launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) break;
        }
        if (launch == null) {
            Toast.makeText(this, "Không tìm thấy biểu tượng mở TikTok Lite. Hãy mở TikTok Lite thủ công; tự vuốt vẫn đang bật.", Toast.LENGTH_LONG).show();
        } else {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(launch);
        }
    }

    private void setRunning(boolean running) {
        getSharedPreferences("swipe", MODE_PRIVATE).edit().putBoolean("running", running).apply();
        refresh();
        Toast.makeText(this, running ? "Đã bật: mở TikTok Lite và chờ 10–15 giây" : "Đã dừng", Toast.LENGTH_LONG).show();
    }

    private void refresh() {
        boolean running = getSharedPreferences("swipe", MODE_PRIVATE).getBoolean("running", false);
        String last = getSharedPreferences("swipe", MODE_PRIVATE)
                .getString("last_result", "Chưa ghi nhận lần vuốt nào");
        status.setText((running ? "Trạng thái: ĐANG CHẠY" : "Trạng thái: ĐÃ DỪNG")
                + "\n" + last);
        status.setTextColor(running ? Color.rgb(0, 120, 40) : Color.rgb(180, 30, 30));
    }

    private void showNewComment() {
        currentComment = JapaneseCommentSuggestions.next();
        if (commentSuggestion != null) commentSuggestion.setText(currentComment);
    }

    private void copyComment() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Japanese comment", currentComment));
        Toast.makeText(this, "Đã sao chép. Hãy thay phần [ ] theo đúng nội dung video rồi tự bấm gửi.", Toast.LENGTH_LONG).show();
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
