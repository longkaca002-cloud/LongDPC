package com.longkaca.autoswipe;

import java.util.Random;

/**
 * Gợi ý có chỗ trống bắt buộc để người dùng viết theo nội dung thật của video.
 * App không tự mở ô bình luận và không tự gửi nội dung.
 */
final class JapaneseCommentSuggestions {
    private static final String[] COMMENTS = {
            "[具体的な場面]のところが特に好きです！",
            "[動画のテーマ]について、もう少し知りたいです。",
            "[具体的なポイント]がとても参考になりました。",
            "[印象に残った内容]がすごく面白かったです！",
            "[紹介されたもの]を私も試してみたいです。",
            "[場所や料理の名前]がとても素敵ですね！",
            "[役に立った部分]を分かりやすく説明してくれて、ありがとうございます。",
            "[好きだった音・動き・場面]がとても印象的でした。"
    };
    private static final Random RANDOM = new Random();
    private static int previous = -1;

    private JapaneseCommentSuggestions() {}

    static String next() {
        int index;
        do {
            index = RANDOM.nextInt(COMMENTS.length);
        } while (COMMENTS.length > 1 && index == previous);
        previous = index;
        return COMMENTS[index];
    }
}
