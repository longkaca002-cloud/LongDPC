package com.longkaca.dpc;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

public final class VpnLockdownManager {
    public static final String DEFAULT_VPN_PACKAGE = "com.volna.proxy";

    private VpnLockdownManager() {}

    private static ComponentName admin(Context c) {
        return new ComponentName(c, LongDeviceAdminReceiver.class);
    }

    public static boolean isInstalled(Context c, String packageName) {
        try {
            c.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static void openVpnApp(Context c, String packageName) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(packageName);
        if (i == null) throw new IllegalStateException("Chưa cài app VPN: " + packageName);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    /** Enables Android always-on VPN lockdown: no VPN means no network for normal apps. */
    public static void enable(Context c, String packageName) throws Exception {
        DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (dpm == null || !dpm.isDeviceOwnerApp(c.getPackageName())) {
            throw new SecurityException("LongDPC chưa phải Device Owner");
        }
        if (!isInstalled(c, packageName)) {
            throw new IllegalStateException("Chưa cài app VPN: " + packageName);
        }
        dpm.setAlwaysOnVpnPackage(admin(c), packageName, true);
    }

    public static void disable(Context c) throws Exception {
        DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (dpm == null || !dpm.isDeviceOwnerApp(c.getPackageName())) {
            throw new SecurityException("LongDPC chưa phải Device Owner");
        }
        dpm.setAlwaysOnVpnPackage(admin(c), null, false);
    }

    public static String status(Context c) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);
            String pkg = dpm.getAlwaysOnVpnPackage(admin(c));
            if (pkg == null) return "CHƯA KHÓA MẠNG";
            return "ĐÃ KHÓA: mất VPN = mất mạng\nVPN: " + pkg;
        } catch (Exception e) {
            return "Không đọc được trạng thái: " + e.getMessage();
        }
    }
}
