package com.longkaca.dpc;

public final class AppCatalog {
    private AppCatalog() {}

    public static final String DEFAULT_DPC_URL =
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/v2.8-test/app-debug.apk";

    public static final String DEFAULT_WIFI_SSID = "Longkaca5G";
    public static final String DEFAULT_WIFI_PASSWORD = "15082020";

    public static final String[] NAMES = {
            "TikTok Nhật", "TikTok Lite Nhật", "LINE", "Long Auto Swipe", "Gmail", "Long OCR", "Volna VPN"
    };

    public static final String[] PACKAGES = {
            "com.ss.android.ugc.trill",
            "com.ss.android.ugc.tiktok.lite",
            "jp.naver.line.android",
            "com.longkaca.autoswipe",
            "com.google.android.gm",
            "com.longkaca.ocr",
            "com.volna.proxy"
    };

    // Toàn bộ ứng dụng phụ dùng chung một release apps-v2 để tránh URL 404.
    public static final String[] DEFAULT_URLS = {
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/apps-v2/tiktok.apks",
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/apps-v2/tiktok-lite.apks",
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/apps-v2/line.apks",
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/apps-v2/long-auto-swipe.apk",
            "",
            "https://github.com/longkaca002-cloud/LongDPC/releases/download/apps-v2/long-ocr-v14.apk",
            ""
    };
}
