# LongDPC v2.9 Proxy Lockdown + Long OCR 1.4 + Long Auto Swipe 1.3

## Proxy tĩnh và khóa chống lộ IP

- Máy mẹ nhận tối đa 10 proxy SOCKS5 dạng `host:port:user:password` và tạo QR lần lượt.
- Chỉ dùng mỗi QR cho một máy; chỉ số đã cấp được lưu lại để tránh cấp trùng sau khi đóng app.
- Máy con mở Volna, quét QR, kết nối và kiểm tra IP Nhật trước.
- Sau khi kiểm tra thành công, LongDPC đặt Volna làm Always-on VPN với lockdown.
- Khi VPN/proxy mất, Android chặn mạng của ứng dụng thay vì quay về IP Wi-Fi/SIM.
- Có nút mở khóa khẩn cấp trong LongDPC. Không bật lockdown trước khi profile VPN hoạt động.

Volna phải được cài từ APK hợp lệ hoặc thủ công từ Google Play. Ô URL Volna để trống mặc định vì dự án không nhúng APK của bên thứ ba.

## Mặc định máy mẹ

- Wi-Fi: `Longkaca5G`; password: `15082020`.
- Chọn APN `jconnect` hoặc `LINEモバイル` trước khi tạo QR.
- Gmail để trống vì giữ Gmail hệ thống có sẵn.

## Release assets

Tag `apps-v2`:

- `tiktok.apks`
- `tiktok-lite.apks`
- `line.apks`
- `long-auto-swipe.apk`
- `long-ocr-v14.apk`

Tag `v2.8-test`:

- `app-debug.apk`

## Long OCR 1.4

Ứng dụng chụp ảnh chất lượng cao, lấy nét khi chạm, sắp xếp dòng OCR theo tọa độ từ trên xuống, ghép tối đa ba dòng và trích mọi email có domain kết thúc bằng `.us`. Kết quả dừng ngay sau `.us`, không lấy phần `|mật khẩu`. Mỗi email có nút sao chép và trạng thái `ĐÃ COPY`.

## Kiểm tra

```bash
python3 tools_static_check.py
```

GitHub Actions build `LongDPC-debug-apk`, `LongOCR-debug-apk` và `LongAutoSwipe-debug-apk`.

LongDPC tự cài lại tối đa bốn vòng và bỏ qua package đã cài, giúp phục hồi khi mạng hoặc firmware dừng vòng đầu.
Trình tải APK/APKS lưu phần đã nhận và dùng HTTP Range để nối tiếp tối đa tám lần khi đường truyền bị ngắt.

## Long Auto Swipe 1.1

App riêng không quảng cáo và không xin quyền Internet. Sau khi người dùng bật dịch vụ Trợ năng một lần, app chỉ vuốt lên trong TikTok Lite `com.ss.android.ugc.tiktok.lite`, với khoảng chờ ngẫu nhiên 10–15 giây. Android không cho Device Owner tự bật dịch vụ Trợ năng trên mọi ROM.

Bản 1.1 khai báo package visibility cho Android 11–16 để nút bắt đầu tìm thấy và mở TikTok Lite, đồng thời hỗ trợ package Lite dự phòng `com.zhiliaoapp.musically.go`.

Bản 1.2 bật đọc cửa sổ tương tác và nhận sự kiện TikTok Lite để sửa trường hợp app mở được nhưng không vuốt trên một số firmware AQUOS/arrows. Màn hình app ghi lại lần vuốt thành công gần nhất.

## Long Auto Swipe 1.3

- Giữ cơ chế mở TikTok Lite và vuốt sau 10–15 giây của bản 1.2.
- Không tự like, không tự mở ô bình luận và không tự gửi nội dung.
- Có gợi ý bình luận tiếng Nhật với phần `[ ]` bắt buộc người dùng sửa theo đúng video rồi tự dán và gửi.
- Sau mỗi 8–12 lần vuốt, app nhắc người dùng chỉ tương tác thủ công khi thật sự phù hợp.
