package com.longkaca.dpc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Android 12+ admin-integrated provisioning finalization hook. */
public class PolicyComplianceActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(Activity.RESULT_OK, new Intent());
        finish();
        PlayUpdateScheduler.schedule(this);
    }
}
