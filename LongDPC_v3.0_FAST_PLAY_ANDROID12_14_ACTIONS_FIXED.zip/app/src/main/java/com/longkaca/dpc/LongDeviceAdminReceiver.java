package com.longkaca.dpc;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class LongDeviceAdminReceiver extends DeviceAdminReceiver {
    @Override public void onProfileProvisioningComplete(Context context, Intent intent) {
        super.onProfileProvisioningComplete(context, intent);
        PlayUpdateScheduler.schedule(context);
    }
    @Override public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        PlayUpdateScheduler.schedule(context);
    }
}
