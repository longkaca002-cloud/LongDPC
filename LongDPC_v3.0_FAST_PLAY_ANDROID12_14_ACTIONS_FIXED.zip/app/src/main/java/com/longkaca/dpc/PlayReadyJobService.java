package com.longkaca.dpc;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

public class PlayReadyJobService extends JobService {
    private static final String TAG = "LongDPC-Play";

    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                PackageManager pm = getPackageManager();
                enableIfPresent(pm, "com.google.android.gms");
                enableIfPresent(pm, "com.android.vending");
                logVersion(pm, "com.google.android.gms");
                logVersion(pm, "com.android.vending");
                getSharedPreferences("play", MODE_PRIVATE).edit()
                        .putLong("last_network_ready", System.currentTimeMillis()).apply();
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    private void enableIfPresent(PackageManager pm, String pkg) {
        try {
            pm.getPackageInfo(pkg, 0);
            int state = pm.getApplicationEnabledSetting(pkg);
            if (state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED ||
                    state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER) {
                pm.setApplicationEnabledSetting(pkg,
                        PackageManager.COMPONENT_ENABLED_STATE_DEFAULT, 0);
            }
        } catch (Exception e) {
            Log.w(TAG, pkg + " unavailable: " + e);
        }
    }

    private void logVersion(PackageManager pm, String pkg) {
        try {
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            long v = android.os.Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            Log.i(TAG, pkg + " version=" + v);
        } catch (Exception ignored) {}
    }

    @Override public boolean onStopJob(JobParameters params) { return true; }
}
