package com.longkaca.dpc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class ProvisioningSuccessActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PlayUpdateScheduler.schedule(this);
        startActivity(new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        finish();
    }
}
