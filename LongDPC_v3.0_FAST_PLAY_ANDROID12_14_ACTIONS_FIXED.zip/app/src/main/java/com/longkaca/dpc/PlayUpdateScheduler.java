package com.longkaca.dpc;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;

public final class PlayUpdateScheduler {
    private static final int JOB_ID = 31014;
    private PlayUpdateScheduler() {}

    public static void schedule(Context context) {
        JobScheduler js = context.getSystemService(JobScheduler.class);
        if (js == null) return;
        JobInfo.Builder b = new JobInfo.Builder(JOB_ID,
                new ComponentName(context, PlayReadyJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setMinimumLatency(1_000L)
                .setBackoffCriteria(30_000L, JobInfo.BACKOFF_POLICY_EXPONENTIAL);
        if (Build.VERSION.SDK_INT >= 31) b.setExpedited(true);
        try { js.schedule(b.build()); }
        catch (Exception ignored) {
            try {
                js.schedule(new JobInfo.Builder(JOB_ID,
                        new ComponentName(context, PlayReadyJobService.class))
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .setPersisted(true).build());
            } catch (Exception ignored2) {}
        }
    }
}
