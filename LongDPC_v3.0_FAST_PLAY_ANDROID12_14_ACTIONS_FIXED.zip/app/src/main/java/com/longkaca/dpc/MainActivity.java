package com.longkaca.dpc;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16); root.setPadding(p,p,p,p);
        ScrollView sv = new ScrollView(this); sv.addView(root); setContentView(sv);
        DevicePolicyManager dpm = getSystemService(DevicePolicyManager.class);
        if (dpm != null && dpm.isDeviceOwnerApp(getPackageName())) showChild(); else showMother();
    }

    private void showMother() {
        text("MÁY MẸ — FAST PLAY QR (Android 12–14)", 22);
        text("QR không chứa Wi‑Fi, không APK phụ, không APN. Android 13–14 có cờ offline; Android 12 bỏ qua cờ này.", 15);
        EditText url = field("HTTPS trực tiếp LongDPC APK", "");
        EditText sum = field("SHA-256 signing certificate URL-safe Base64", signingChecksum());
        ImageView qr = new ImageView(this); root.addView(qr, new LinearLayout.LayoutParams(-1, dp(420)));
        Button make = button("TẠO QR TỐI GIẢN");
        make.setOnClickListener(v -> {
            try {
                String u=url.getText().toString().trim(), s=sum.getText().toString().trim();
                if (!u.startsWith("https://") || s.isEmpty()) throw new IllegalArgumentException("Cần URL HTTPS và checksum chữ ký");
                JSONObject j = new JSONObject();
                j.put("android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME",
                        "com.longkaca.dpc/com.longkaca.dpc.LongDeviceAdminReceiver");
                j.put("android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION", u);
                j.put("android.app.extra.PROVISIONING_DEVICE_ADMIN_SIGNATURE_CHECKSUM", s);
                j.put("android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED", true);
                if (Build.VERSION.SDK_INT >= 33) j.put("android.app.extra.PROVISIONING_ALLOW_OFFLINE", true);
                Bitmap bmp=QrUtil.make(j.toString(),1000); qr.setImageBitmap(bmp);
            } catch(Exception e) { Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); }
        });
    }

    private void showChild() {
        text("MÁY CON — FAST PLAY",22);
        text("LongDPC đang chờ Wi‑Fi/4G. Khi có Internet, job hệ thống chạy ngay để đánh thức Google Play components và kiểm tra trạng thái Google Play services.",15);
        PlayUpdateScheduler.schedule(this);
        Button check = button("KIỂM TRA GOOGLE PLAY SERVICES NGAY");
        check.setOnClickListener(v -> checkPlayServices(true));
        checkPlayServices(false);
    }

    private void checkPlayServices(boolean userRequested) {
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this);
        if (code == ConnectionResult.SUCCESS) {
            Toast.makeText(this,"Google Play services đang hoạt động",Toast.LENGTH_LONG).show();
            return;
        }
        if (GoogleApiAvailability.getInstance().isUserResolvableError(code)) {
            if (userRequested) GoogleApiAvailability.getInstance().getErrorDialog(this, code, 9001).show();
        } else if (userRequested) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.google.android.gms")));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:com.google.android.gms")));
            }
        }
    }

    private String signingChecksum() {
        try { return ChecksumUtil.installedSigningCertSha256Base64Url(this); }
        catch(Exception e) { return ""; }
    }
    private EditText field(String hint,String val){ EditText e=new EditText(this);e.setHint(hint);e.setText(val);root.addView(e);return e; }
    private Button button(String s){Button b=new Button(this);b.setText(s);root.addView(b);return b;}
    private void text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,0,0,dp(12));root.addView(t);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
