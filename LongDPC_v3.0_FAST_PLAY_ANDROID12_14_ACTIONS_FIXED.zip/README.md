# LongDPC v3.0 FAST PLAY — Android 12–14

Mục tiêu duy nhất:
1. Factory reset -> 6 taps -> scan QR.
2. QR không chứa Wi-Fi/APN/app phụ.
3. Provision LongDPC as Device Owner.
4. Khi có bất kỳ network (Wi-Fi / cellular), JobScheduler chạy ngay.
5. LongDPC kiểm tra/đánh thức `com.google.android.gms` và `com.android.vending` nếu có trên ROM, rồi Google tự quản lý quá trình cập nhật.

## Giới hạn Android / Google
- Không có public DevicePolicyManager API cho DPC tự cài đè hoặc ép Google Play services cập nhật tức thời/silent.
- `PROVISIONING_ALLOW_OFFLINE` chỉ tồn tại từ Android 13 (API 33). Android 12 vẫn cần đường mạng nếu Setup Wizard phải tải DPC từ URL.
- Nút kiểm tra trong app dùng GoogleApiAvailability để mở luồng sửa/cập nhật chính thức khi Google Play services báo lỗi có thể xử lý.

## Build
- JDK 17
- Android SDK 34
- `./gradlew :app:assembleDebug` hoặc GitHub Actions.
- Release phải ký bằng cùng certificate với bản dùng trên máy mẹ để checksum QR khớp.
